﻿using HotelManager.Domain.Entity.Accounts;
using HotelManager.Domain.Entity.Bookings;

namespace HotelManager.Domain.Entity.Ratings
{
    public class Rating
    {
        protected Rating() { }

        public int Id { get; private set; }
        public string BookingId { get; private set; }
        public Booking? Booking { get; private set; }
        public int NumOfRating { get; private set; }
        public string? Review { get; private set; }

        public Rating(string bookingId, int numOfRating, string review)
        {
            if (numOfRating < 0 || numOfRating > 5) throw new ArgumentException("Điểm đánh giá không hợp lệ");
            BookingId = bookingId;
            NumOfRating = numOfRating;
            Review = review;
        }
    }
}
