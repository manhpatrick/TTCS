﻿namespace HotelManager.Domain.Entity.Rooms.Enum
{
    public enum RoomStatus
    {
        Available = 1,
        IsRent = 2,
        IsBooking = 3
    }
}
