﻿using HotelManager.Domain.Entity.Bookings;
using HotelManager.Domain.Entity.Rooms.Enum;

namespace HotelManager.Domain.Entity.Rooms
{
    public class Room
    {
        protected Room() { }
        public int RoomId { get; private set; }
        public string RoomName { get; private set; }
        public int Capacity { get; private set; }
        public RoomStatus RoomStatus { get; private set; }
        public decimal PricePerMonth { get; private set; }
        public ICollection<Booking> Bookings { get; private set; } = new List<Booking>();

        public Room(string roomName, int capacity, RoomStatus roomStatus, decimal pricePerMonth)
        {
            ChangeRoomName(roomName);
            ChangeCapacity(capacity);
            ChangeRoomStatus(roomStatus);
            ChangePricePerMonth(pricePerMonth);
        }
        public void ChangeCapacity(int newCapacity)
        {
            if (Capacity < 0) throw new ArgumentException("Sức chứa không hợp lệ");
            Capacity = newCapacity;
        }
        public void ChangeRoomName(string newRoomName)
        {
            if (string.IsNullOrWhiteSpace(newRoomName)) throw new ArgumentException("Tên phòng không được trống");
            RoomName = newRoomName;
        }
        public void ChangePricePerMonth(decimal newPricePerMonth)
        {
            if (Capacity < 0) throw new ArgumentException("Giá tiền không hợp lệ");
            PricePerMonth = newPricePerMonth;
        }
        public void ChangeRoomStatus(RoomStatus newRoomStatus)
        {
            if (!System.Enum.IsDefined(typeof(RoomStatus),RoomStatus)) throw new ArgumentException("Trạng thái phòng không hợp lệ");
            RoomStatus = newRoomStatus;
        }
    }
}
