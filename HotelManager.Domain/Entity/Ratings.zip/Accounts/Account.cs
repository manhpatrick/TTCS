﻿using HotelManager.Domain.Entity.Accounts.Enum;
using HotelManager.Domain.Entity.Bookings;
using HotelManager.Domain.Entity.Users;

namespace HotelManager.Domain.Entity.Accounts
{
    public class Account
    {
        protected Account() { }
        public int AccountId { get; private set; }
        public string Username { get; private set; }
        public string PasswordHash { get; private set; }
        public RoleAccount Role { get; private set; }
        public bool IsActive { get; private set; }
        public User? User { get; private set; }
        public ICollection<Booking> Bookings { get; private set; } = new List<Booking>();
        public Account(string username, string passwordHash)
        {
            if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("Username không được để trống");

            Username = username;
            ChangePasswordHash(passwordHash);
            ChangeRole(RoleAccount.Customer);
            IsActive = true;
        }
        public void ChangePasswordHash(string newPasswordHash)
        {
            if (string.IsNullOrWhiteSpace(newPasswordHash)) throw new ArgumentException("Mật khẩu mã hoá không được trống");
            PasswordHash = newPasswordHash;
        }
        public void ChangeRole(RoleAccount role)
        {
            if (!System.Enum.IsDefined(typeof(RoleAccount), role)) throw new ArgumentException("Role không hợp lệ");
            Role = role;
        }
        public void ChangeIsActive(bool newIsActive)
        {
            IsActive = newIsActive;
        }
    }
}
