﻿namespace HotelManager.Domain.Entity.Accounts.Enum
{
    public enum RoleAccount
    {
        Role = 1,
        Customer = 2
    }
}
