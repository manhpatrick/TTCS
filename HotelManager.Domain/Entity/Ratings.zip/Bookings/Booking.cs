﻿using HotelManager.Domain.Entity.Accounts;
using HotelManager.Domain.Entity.Bookings.Enum;
using HotelManager.Domain.Entity.Ratings;
using HotelManager.Domain.Entity.Rooms;

namespace HotelManager.Domain.Entity.Bookings
{
    public class Booking
    {
        protected Booking() { }
        public string BookingId { get; private set; }
        public int NumOfPeople { get; private set; }
        public DateTime StartTime { get; private set; }
        public DateTime? EndTime { get; private set; }
        public BookingStatus? BookingStatus { get; private set; }
        public DateTime? ApprovedAt { get; private set; }
        public int AccountId { get; private set; }
        public Account? Account { get; private set; }
        public int RoomId { get; private set; }
        public Room? Room { get; private set; }
        public Rating? Rating { get; private set; }

        public Booking(string accountId, string roomId, DateTime startTime, int numOfPeople)
        {
            BookingId = "Book+" + DateTime.UtcNow.ToString("yyyy-MM-dd");
            ChangeStartTime(startTime);
            ChangeAccountId(accountId);
            ChangeRoomId(roomId);
            ChangeNumOfPeople(numOfPeople);
        }
        public void ChangeStartTime(DateTime newStartTime)
        {
            StartTime = newStartTime;
        }
        public void ChangeAccountId(string newAccountId)
        {
            if (string.IsNullOrWhiteSpace(newAccountId)) throw new ArgumentException("AccountId không hợp lệ");
            AccountId = newAccountId;
        }
        public void ChangeRoomId(string newRoomId)
        {
            if (string.IsNullOrWhiteSpace(newRoomId)) throw new ArgumentException("RoomId không hợp lệ");
            RoomId = newRoomId;
        }
        public void ChangeNumOfPeople(int newNumOfPeople)
        {
            if (newNumOfPeople <= 0) throw new ArgumentException("Số người phải lớn hơn 0");
            NumOfPeople = newNumOfPeople;
        }
        public void SetEndTime(DateTime newEndTime)
        {
            if (newEndTime < StartTime) throw new ArgumentException("Ngày kết thúc phải lớn hơn ngày bắt đầu");
            EndTime = newEndTime;
        }
        public void SetApproved(BookingStatus newBookingStatus)
        {
            BookingStatus = newBookingStatus;
            ApprovedAt = DateTime.UtcNow;
        }
    }
}
