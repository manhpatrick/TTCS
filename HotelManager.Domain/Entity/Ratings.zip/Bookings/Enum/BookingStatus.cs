﻿
namespace HotelManager.Domain.Entity.Bookings.Enum
{
    public enum BookingStatus
    {
        Pending = 1,                //chờ xác nhận
        Approved = 2,               //Admin xác nhận
        Rejected = 3,               //Admin từ chối
        Cancelled = 4               //Khách huỷ
    }
}
